import TentangKami1 from "./tentangkami1.jpg";
import TentangKami2 from "./tentangkami2.jpg";
import TentangKami3 from "./tentangkami3.jpg";
import Header from "./header.jpg";
import AboutUs1 from "./aboutus1.jpg";
import AboutUs2 from "./aboutus2.png";

export { TentangKami1, TentangKami2, TentangKami3, Header, AboutUs1, AboutUs2 };
