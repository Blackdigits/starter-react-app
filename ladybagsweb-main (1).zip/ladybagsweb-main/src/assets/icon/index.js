import Logo from "./logo.png";
import InstagramLogo from "./instagram-logo.png";
import FacebookLogo from "./facebook-logo.png";
import BcaLogo from "./bca-logo.png";
import MandiriLogo from "./mandiri-logo.png";
import BriLogo from "./bri-logo.png";
import BniLogo from "./bni-logo.png";
import JneLogo from "./jne.png";
import JntLogo from "./j&t.png";
import PosLogo from "./pos-logo.png";
import SiCepatLogo from "./sicepat.png";
import TikiLogo from "./tiki.png";
import LionParcelLogo from "./lionparcel.png";

export {
  Logo,
  InstagramLogo,
  FacebookLogo,
  BcaLogo,
  MandiriLogo,
  BriLogo,
  BniLogo,
  JneLogo,
  JntLogo,
  PosLogo,
  SiCepatLogo,
  LionParcelLogo,
  TikiLogo,
};
